.. _biom_format:

===========================================
Biological Observation Matrix (BIOM) format
===========================================

QIIME stores its sample x observation matrices (e.g., OTU tables) in the BIOM file format. For more information about the BIOM file format, please visit http://biom-format.org.
