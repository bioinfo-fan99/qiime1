max_e_value_blast	1e-5
max_cdhit_memory	800
sortmerna_coverage	.80
sortmerna_max_pos	9999
BLAST OTU pickeraligned_percent	0.75(75%)
Sequence similarity threshold	0.80
rev_strand_match	True
Percent identity threshold for cluster error detection	0.80(80%)
Percent ID for mapping OTUs created by usearch	0.80(80%)
Minimum length of sequence	61
cdhit similarity	0.70(70%)

