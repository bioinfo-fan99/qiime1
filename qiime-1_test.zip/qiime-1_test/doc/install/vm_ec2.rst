.. _ec2:

This page has been replaced with the `QIIME AWS tutorial <../tutorials/working_with_aws.html>`_.
