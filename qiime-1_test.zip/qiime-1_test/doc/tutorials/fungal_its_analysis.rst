.. _fungal_its_tutorial:

==============================================================================
Fungal ITS analysis tutorial (an IPython Notebook): open-reference OTU picking
==============================================================================

This tutorial is provided as an IPython Notebook. See the `Fungal ITS analysis tutorial IPython Notebook <http://nbviewer.ipython.org/github/biocore/qiime/blob/1.9.1/examples/ipynb/Fungal-ITS-analysis.ipynb>`_.
