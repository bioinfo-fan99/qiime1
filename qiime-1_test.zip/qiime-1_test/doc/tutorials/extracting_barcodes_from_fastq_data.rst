.. _extracting_barcodes:

=====================================================================================
Extracting Barcodes from fastq data for compatibility with `split_libraries_fastq.py`
=====================================================================================

This document has been merged with the `Processing Illumina Data <./processing_illumina_data.html>`_ tutorial.
