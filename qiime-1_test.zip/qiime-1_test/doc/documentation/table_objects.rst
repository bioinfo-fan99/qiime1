.. _table_objects:

===============
BIOM format API
===============

For more information about the BIOM format API, please visit http://biom-format.org.
