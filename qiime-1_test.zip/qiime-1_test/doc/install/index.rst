.. _install_index:

=====================
Installing QIIME
=====================

.. toctree::
   :maxdepth: 1
   :glob:

   install
   alternative
   virtual_box
   upgrade
   qiime_config
