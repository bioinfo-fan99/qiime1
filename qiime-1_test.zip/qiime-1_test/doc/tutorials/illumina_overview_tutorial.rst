.. _illumina_overview_tutorial:

========================================================================================================
Illumina Overview Tutorial (an IPython Notebook): open reference OTU picking and core diversity analyses
========================================================================================================

This tutorial is provided as an IPython Notebook. See the `Illumina Overview Tutorial IPython Notebook <http://nbviewer.ipython.org/github/biocore/qiime/blob/1.9.1/examples/ipynb/illumina_overview_tutorial.ipynb>`_.
