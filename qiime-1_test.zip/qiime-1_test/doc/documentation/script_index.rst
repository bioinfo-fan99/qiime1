.. _scripts: Script Index

The QIIME script index has moved
--------------------------------

This page has moved `here <../scripts/index.html>`_.
